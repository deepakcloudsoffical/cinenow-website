<div>
<a href="{{ route('livetv-details', ['id' => $value['id']]) }}" class="channel-card d-flex align-content-center align-items-center justify-content-center">
    <img src="{{$value['poster_image']}}" alt="channel icon" class="img-fluid object-cover rounded channel-img">
</a>
</div>
