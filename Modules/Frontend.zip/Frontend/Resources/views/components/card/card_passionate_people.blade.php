<div class="passionate-people rounded-3">
    <div class="text-center">
        <h5 class="line-count-1">Ethan Carter</h5>
        <p class="designation text-white fst-italic mb-0">CEO of Streamit</p>
            <img src="../img/web-img/passionate_1.png" alt="user" class="img-fluid passionate-people-img">
        <p class="text-white mb-0">Dummy text goes here</p>
     </div>
 </div>            