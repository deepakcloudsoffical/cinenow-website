<?php

namespace Modules\Frontend\Trait;

use App\Models\UserMultiProfile;


trait paymentTrait
{

    public function CheckDeviceLimit($user, $current_device)
    {




    }



}
