<?php

namespace Modules\Filemanager\Http\Controllers\API;

class FilemanagersController extends Controller
{
  // api controller logic
}
