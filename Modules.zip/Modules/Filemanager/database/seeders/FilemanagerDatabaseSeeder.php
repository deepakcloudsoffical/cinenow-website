<?php

namespace Modules\Filemanager\database\seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Arr;
use Modules\Filemanager\Models\Filemanager;
use Modules\MenuBuilder\Models\MenuBuilder;

class FilemanagerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
