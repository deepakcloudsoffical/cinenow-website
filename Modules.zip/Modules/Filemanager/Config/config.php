<?php

return [
    'name' => 'Filemanager',
];
