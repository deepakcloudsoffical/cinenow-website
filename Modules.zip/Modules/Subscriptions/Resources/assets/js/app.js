import { InitApp } from '@/helpers/main'


const app = InitApp()


app.mount('[data-render="app"]');



