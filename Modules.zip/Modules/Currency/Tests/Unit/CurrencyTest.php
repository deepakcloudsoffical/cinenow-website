<?php

namespace Modules\Currency\Tests\Unit;

use PHPUnit\Framework\TestCase;

class CurrencyTest extends TestCase
{
    /**
     * A basic test Currency.
     *
     * @return void
     */
    public function test_that_true_is_true()
    {
        $this->assertTrue(true);
    }
}
