<?php

namespace Modules\Currency\Http\Controllers\API;

class CurrenciesController extends Controller
{
  // api controller logic
}
