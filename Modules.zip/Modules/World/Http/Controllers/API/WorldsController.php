<?php

namespace Modules\World\Http\Controllers\API;

class WorldsController extends Controller
{
  // api controller logic
}
