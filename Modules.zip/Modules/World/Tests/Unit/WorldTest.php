<?php

namespace Modules\World\Tests\Unit;

use PHPUnit\Framework\TestCase;

class WorldTest extends TestCase
{
    /**
     * A basic test World.
     *
     * @return void
     */
    public function test_that_true_is_true()
    {
        $this->assertTrue(true);
    }
}
