<?php

namespace Modules\Coupon\database\seeders;

use Illuminate\Database\Seeder;

class CouponDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
