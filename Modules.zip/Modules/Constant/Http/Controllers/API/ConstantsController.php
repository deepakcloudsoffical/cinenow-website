<?php

namespace Modules\Constant\Http\Controllers\API;

class ConstantsController extends Controller
{
  // api controller logic
}
