<?php

return [
    'name' => 'Constant',
];
