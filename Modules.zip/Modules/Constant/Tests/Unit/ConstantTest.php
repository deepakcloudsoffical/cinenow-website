<?php

namespace Modules\Constant\Tests\Unit;

use PHPUnit\Framework\TestCase;

class ConstantTest extends TestCase
{
    /**
     * A basic test Constant.
     *
     * @return void
     */
    public function test_that_true_is_true()
    {
        $this->assertTrue(true);
    }
}
