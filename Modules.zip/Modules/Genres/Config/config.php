<?php

return [
    'name' => 'Genres',
];
