<?php

return [
    'name' => 'NotificationTemplate',
    'channels' => [
        'IS_MAIL' => 'Mail',
        'PUSH_NOTIFICATION' => 'Mobile',
    ],
];
