<?php

namespace Modules\Tax\Http\Controllers\API;

class TaxesController extends Controller
{
  // api controller logic
}
