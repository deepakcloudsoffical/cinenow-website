<?php

namespace Modules\Tax\Tests\Unit;

use PHPUnit\Framework\TestCase;

class TaxTest extends TestCase
{
    /**
     * A basic test Tax.
     *
     * @return void
     */
    public function test_that_true_is_true()
    {
        $this->assertTrue(true);
    }
}
